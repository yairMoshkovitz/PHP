-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2018 at 04:41 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank`
--
CREATE Database bank ;

-- --------------------------------------------------------

--
-- Table structure for table `bank_account`
--

CREATE TABLE `transfers` (
  `trans_id` int(10) NOT NULL,
  `transferor_id`  varchar(50) NOT NULL,
  `receiver_id` varchar(50) NOT NULL,
  `money_to_trans` int(6) ,
  `date_of_trans` DATE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for table `transfers`
--
ALTER TABLE `transfers`
  ADD PRIMARY KEY (`trans_id`);

--
-- AUTO_INCREMENT for table `transfers`
--

ALTER TABLE `transfers`
  MODIFY `trans_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;


-- --------------------------------------------------------

--
-- Table structure for table `bank_account`
--

CREATE TABLE `bank_account` (
  `user_id` int(10) NOT NULL,
  `account`  int(11) NOT NULL  DEFAULT '0',
  `Line_of_credit` int(11) NOT NULL  DEFAULT '1000',
  `privileges` int(2) NOT NULL  DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bank_account`
--

INSERT INTO `bank_account` (`user_id`, `account`, `Line_of_credit`, `privileges`) VALUES
(1, 2000000, 10000, 10),
(2, 1000, 2000, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `date` DATE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`,`date`) VALUES
(1, 'admin', 'A123456a', '2023-03-19'),
(2, 'roman', 'asdAFSC!@#EFEDS!@#WREFD','2023-03-19'),
(3, 'l33t', '1337','2023-03-19');

--
-- Indexes for table `bank_account`
--
ALTER TABLE `pobank_accountsts`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);


--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;



/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
